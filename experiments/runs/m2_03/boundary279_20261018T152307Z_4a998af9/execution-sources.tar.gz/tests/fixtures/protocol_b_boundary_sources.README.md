# Boundary observer source fixture

Four unmodified official vLLM v0.30.0 Python sources, selected from archive
`a7b52e7ee7cd1ce315f3c126cb5c0d8fa0e4ca25`'s
`tests/fixtures/m203_v030_sources.json.gz`. No experiment outputs are included.

`experiments/protocol_b_boundary_sources.py` pins their SHA-256 hashes. CPU tests
apply the observation-only insertions to these real sources, compile the result,
and verify that stripping observation calls recovers the original AST.

Upstream: https://github.com/vllm-project/vllm/tree/v0.30.0
License: Apache-2.0, included in `protocol_b_boundary_LICENSE.txt`.

## Executed V2 sampler

`protocol_b_boundary_v2_v030.json.gz` contains only the unmodified V2 sampler
from checkpoint `31d31f242af55faecb262114e738aa0340c07429`, under
`experiments/runs/m2_03/boundary279_20261018T115933Z_0267339f/vllm-v2-executed-sources/`.
Its SHA-256 is `832c9945d201a1e730ff9b4b52076aa83bd4a5064e1e4cfea952cf84d4a8d1f0`.
The existing V1 fixture and historical experiment outputs are unchanged.

## Historical K/V source binding

`protocol_b_boundary_kv_v030.json.gz` contains the twelve unmodified upstream
v0.30.0 dependencies enumerated in the approved source-binding review, fetched
from https://github.com/vllm-project/vllm/tree/v0.30.0.
The V2 runner and graph-manager bytes match the earlier preserved executed-source
snapshot. This fixture supports offline transformation tests; it does not prove
identity with the later deployed installation. The next diagnostic must match
every installed source against the pinned SHA-256, preserve pristine bytes, and
record patched hashes only for instrumented files.

The V1 ownership correction additionally pins `v1/spec_decode/draft_model.py`
and `v1/spec_decode/llm_base_proposer.py` from the same upstream tag.
`SpecDecodeBaseProposer.load_model()` maintains `_draft_attn_layer_names`;
`initialize_attn_backend()` builds `draft_attn_groups` from that set.
Both dependencies are authenticated and preserved without instrumentation.
